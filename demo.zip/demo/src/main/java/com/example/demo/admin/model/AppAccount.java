package com.example.demo.admin.model;

import java.util.Date;

public class AppAccount 
{
	
		private Integer accId;

		private String firstName;

		private String lastName;

		private String email;

		private String password;

		private String dob;

		private String gender;

		private Long ssn;

		private String phno;

		private String activeSw;

		private Date createDate;

		private Date updateDate;

		private String role;

		public Integer getAccId() {
			return accId;
		}

		public void setAccId(Integer accId) {
			this.accId = accId;
		}

		public String getFirstName() {
			return firstName;
		}

		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}

		public String getLastName() {
			return lastName;
		}

		public void setLastName(String lastName) {
			this.lastName = lastName;
		}

		public String getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email = email;
		}

		public String getPassword() {
			return password;
		}

		public void setPassword(String password) {
			this.password = password;
		}

		public String getDob() {
			return dob;
		}

		public void setDob(String dob) {
			this.dob = dob;
		}

		public String getGender() {
			return gender;
		}

		public void setGender(String gender) {
			this.gender = gender;
		}

		public Long getSsn() {
			return ssn;
		}

		public void setSsn(Long ssn) {
			this.ssn = ssn;
		}

		public String getPhno() {
			return phno;
		}

		public void setPhno(String phno) {
			this.phno = phno;
		}

		public String getActiveSw() {
			return activeSw;
		}

		public void setActiveSw(String activeSw) {
			this.activeSw = activeSw;
		}

		public Date getCreateDate() {
			return createDate;
		}

		public void setCreateDate(Date createDate) {
			this.createDate = createDate;
		}

		public Date getUpdateDate() {
			return updateDate;
		}

		public void setUpdateDate(Date updateDate) {
			this.updateDate = updateDate;
		}

		public String getRole() {
			return role;
		}

		public void setRole(String role) {
			this.role = role;
		}

		@Override
		public String toString() {
			return "AppAccount [accId=" + accId + ", firstName=" + firstName + ", lastName=" + lastName + ", email=" + email
					+ ", password=" + password + ", dob=" + dob + ", gender=" + gender + ", ssn=" + ssn + ", phno=" + phno
					+ ", activeSw=" + activeSw + ", createDate=" + createDate + ", updateDate=" + updateDate + ", role="
					+ role + ", getAccId()=" + getAccId() + ", getFirstName()=" + getFirstName() + ", getLastName()="
					+ getLastName() + ", getEmail()=" + getEmail() + ", getPassword()=" + getPassword() + ", getDob()="
					+ getDob() + ", getGender()=" + getGender() + ", getSsn()=" + getSsn() + ", getPhno()=" + getPhno()
					+ ", getActiveSw()=" + getActiveSw() + ", getCreateDate()=" + getCreateDate() + ", getUpdateDate()="
					+ getUpdateDate() + ", getRole()=" + getRole() + ", getClass()=" + getClass() + ", hashCode()="
					+ hashCode() + ", toString()=" + super.toString() + "]";
		}
		
}
