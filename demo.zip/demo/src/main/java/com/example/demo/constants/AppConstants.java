package com.example.demo.constants;

public class AppConstants {

	/**
	 * This MESSGE is used to refer message
	 */
	public static final String MESSAGE = "message";

	public static final String CW_REG_SUCCESS = "cwRegSuccess";
	public static final String CW_REG_FAIL = "cwRegFail";
	
	public static final String PLAN_REG_SUCCESS="planSuccess";
	public static final String PLAN_REG_FAIL="planFail";
	

	public static final String SUCCESS="success";
	public static final String FAILURE="failure";
	
	public static final String ACTIVE_SW="Y";
	public static final String IN_ACTIVE_SW="N";

	public static final String REG_EMAIL_FILE_NAME="regEmailFileName";

	public static final String REG_EMAIL_SUBJECT="regEmailSubject";

	public static final String APP_ACCOUNTS="accounts";
	/* public static final String PLAN_ACCOUNTS="planAccounts"; */

	public static final String ACTIVATE_EMAIL_FILE="accActivateEmailFileName";
	public static final String DE_ACTIVATE_EMAIL_FILE="accDeActiveEmailFileName";
	public static final String ACTIVATE_EMAIL_SUB="accActivateEmailSubject";
	public static final String DE_ACTIVATE_EMAIL_SUB="accDeActiveEmailSubject";

	public static final String ACC_ACTIVATE_SUCC_MSG="accActivateSuccMsg";
	public static final String ACC_ACTIVATE_ERR_MSG="accActivateErrMsg";
	
	public static final String ACC_DE_ACTIVATE_SUCC_MSG="accDeActivateSuccMsg";
	public static final String ACC_DE_ACTIVATE_ERR_MSG="accDeActivateErrMsg";
	
	public static final String PLAN_SUCCESS="planSuccess";
	public static final String PLAN_FAILURE="planFail";
	
	
	
	public static final String PLAN_ACTIVATE_SUCC_MSG="planActivateSuccMsg";
	public static final String PLAN_ACTIVATE_ERR_MSG="planActivateErrMsg";
	
	public static final String PLAN_DE_ACTIVATE_SUCC_MSG="planDeActivateSuccMsg";
	public static final String PLAN_DE_ACTIVATE_ERR_MSG="planDeActivateErrMsg";
	
	public static final String VIEW_PLAN="viewPlan";

}
